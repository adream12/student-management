﻿#include "common.h"
#include "menu.h"
#include "file.h"

// Global variable
List    *Tea_list     = createList();
AvlNode *Stu_avl;
List    *SearchTable_list = createList();
void    *Current_User = NULL;


/*
    이    름 : Login()
    역    할 : 로그인 창을 띄움
    파라미터 : 없음
    반 환 값 : int, 접속한 모드를 반환 (Admin / Teacher / Student)
    기    타 : 없음
*/
static int Login()
{
    string Input_ID;
    string Input_PW;
    Student_info *Student_data = NULL;
    ListNode* Teacher_list = NULL;
    AvlNode* Student_avl = NULL;

    layout_head();

    // User should input ID & Password
    cout << "I  D : ";
    cin >> Input_ID;

    cout << "P  W : ";
    cin >> Input_PW;

    // Check ID & Password
    if (Input_ID == "admin" && Input_PW == "admin") // when admin
    {
        cout << "관리자 모드로 접속하셨습니다." << endl;
        PAUSE();
        return ADMIN;
    }
    // when teacher
    else if ((Teacher_list = searchList (Tea_list, Input_ID)) != NULL
            && Input_ID == ((Teacher_info*) Teacher_list->data)->getIDcode()
            && Input_PW == ((Teacher_info*) Teacher_list->data)->getPassword())
    {
        Current_User = Teacher_list->data;
        cout << ((Teacher_info*) Current_User)->getName() << " 선생님, 환영합니다." << endl;
        PAUSE();
        return TEACHER;
    }

    // when student
    else if ((Student_avl = Avl_Search(Stu_avl, Input_ID)) != NULL
            && Input_ID == ((Student_info*) Student_avl->data)->getIDcode()
            && Input_PW == ((Student_info*) Student_avl->data)->getPassword())
    {
        Current_User = Student_avl->data;
        cout << ((Student_info*) Current_User)->getName() << " 님, 환영합니다." << endl;
        PAUSE();
        return STUDENT;
    }

    else    // when fail to certificate
    {
        cout << "ID 또는 패스워드가 일치하지 않습니다." << endl;
        PAUSE();

        return ERROR_MODE;
    }

}


static void Reconstruct_Class (string buffer)
{
    int left = 0, right = 0, end = 0;
    int length = buffer.length();
    int idx;
    void *obj = NULL;
    Search_table *tab = NULL;
    int mode;
    int subject;

    int test_code = 0;

    while (end != length - 1 && end != -1)
    {
        end = buffer.find('\n', right + 1);
        idx = 0;
        subject = 0;
        obj = NULL;
        tab = NULL;
        
        while (right != end)
        {
            string tmp = "";

            if ((right = buffer.find('/', left)) > end)
                right = end;

            if (right == -1)
                break;

            tmp = buffer.substr(left, right - left);

            // Identify mode (whether Teacher or Student)
            if (idx == 0)       // when read mode
            {
                mode = atoi(tmp.c_str());

                if (mode == TEACHER)
                    obj = new Teacher_info;

                else if (mode == STUDENT)
                {
                    obj = new Student_info;
                    tab = new Search_table;
                }
            }

            // Common area
            else if (idx == 1)               // when read IDcode
            {
                ((Primary_info*) obj) -> setIDcode(tmp);

                if (mode == STUDENT)
                    tab -> IDcode = tmp;
            }

            else if (idx == 2)          // when read name
            {
                ((Primary_info*) obj) -> setName(tmp);

                if (mode == STUDENT)
                    tab -> name = tmp;
            }

            else if (idx == 3)          // when read password
                ((Primary_info*) obj) -> setPassword(tmp);

            else if (idx == 4)          // when read birth
                ((Primary_info*) obj) -> setBirth(tmp);

            else if (idx == 5)          // when read grade
                ((Primary_info*) obj) -> setGrade(atoi(tmp.c_str()));

            else if (idx == 6)          // when read class
                ((Primary_info*) obj) -> setClass(atoi(tmp.c_str()));


            // Student area
            if (mode == STUDENT)
            {
                if (idx == 7)               // when read scroe
                {
                    ((Student_info*) obj) -> setScore(atoi(tmp.c_str()), subject);
                    subject++;

                    if (subject != TOTAL_SUBJECT)
                        idx--;
                }

                else if (idx == 8)          // when read score sum
                    ((Student_info*) obj) -> setScoreSum(atoi(tmp.c_str()));

                else if (idx == 9)          // when read score avg
                    ((Student_info*) obj) -> setScoreAvg(atof(tmp.c_str()));

                else if (idx == 10)          // when read class rank
                    ((Student_info*) obj) -> setClassRank(atoi(tmp.c_str()));

                else if (idx == 11)          // when read entire rank
                    ((Student_info*) obj) -> setEntireRank(atoi(tmp.c_str()));
            }
            
            left = right + 1;
            idx++;
        }

#if ERROR_TEST
        cout << "right : " << right << ",  end : " << end << endl;
        cout << "testcode : " << test_code++ << endl;
#endif

        // insert each information to each list
        if (mode == TEACHER)
            addFront(Tea_list, (Teacher_info*) obj);
        else if (mode == STUDENT)
        {
            Avl_Insert (&Stu_avl , (Student_info*) obj);
            addFront(SearchTable_list, tab);
        }
    }
}



int main()
{
    int login_mode;
    string buffer = "";
    
    system ("cls");
    for (int i = 0; i < 11; i++)
        cout << endl;
    cout << "                             " ;
    cout << "Now Loading..." ;
    
    if ((buffer = readFile ()) != "")
    {
#if DEBUG_PRINT
        cout << " :::: In Main :::: "<< endl;
        cout << buffer << endl;
        PAUSE();
#endif
        Reconstruct_Class(buffer);
    }


    // Call Login func
    while(login_mode = Login(), login_mode == ERROR_MODE);   // 로그인 에러시 while loop 수행

    switch (login_mode)
    {
        case ADMIN:
            admin_menu();
            break;

        case TEACHER:
            teacher_menu();
            break;

        case STUDENT:
            student_menu();
            break;

        case ERROR_MODE:
            break;
    }

    destroyList (Tea_list);
    destroyList (SearchTable_list);

    return 0;
}
