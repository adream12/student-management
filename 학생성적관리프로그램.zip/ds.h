﻿#ifndef _DS_H_
#define _DS_H_

/*######################################################################
####                           macro                                ####
######################################################################*/

#define max(a,b)    (((a) > (b)) ? (a) : (b))   // get max valus


/*######################################################################
####                          structure                             ####
######################################################################*/

// AVL Tree
typedef struct _AvlNode AvlNode;
struct _AvlNode
{
    Student_info *data;                  // data's type is class 
    AvlNode *left, *right;       // left child, right child
};

// List
typedef struct _ListNode ListNode;
struct _ListNode
{
    void     *data;
    ListNode *next;
};

typedef struct _List List;
struct _List
{
    int size;
    ListNode* front;
};

// Huffman
typedef struct _chTable
{
    char ch;
    int  frequency;
} chTable;


typedef struct _TreeNode TreeNode;
struct _TreeNode
{
    chTable   table;
    TreeNode *left;
    TreeNode *right;
};

typedef struct _Tree
{
    TreeNode* root;
    int size;
} Tree;


/*######################################################################
####                         AVL TREE                               ####
####                                                                ####
#### Usage: AvlNode *root = NULL;                                   ####
####        and just use! :)                                        ####
######################################################################*/

AvlNode* Avl_Insert (AvlNode **root, Student_info *in);                         // Insert node to avltree
AvlNode* Avl_Search (AvlNode *node, string key);                                // Serach for node
void Avl_Search_All (AvlNode *node, List *list, Primary_info* key, int mode);   // Serach for All node
AvlNode* Avl_Delete (AvlNode **root, string key);                               // Delete node from avltree
void     Avl_FillBuffer (AvlNode *node, string *buf);                           // Get buf made from all node in avltree (To use making buf string)


/*######################################################################
####                         L I S T                                ####
####                                                                ####
#### Usage: List *list = createList();                              ####
####        and just use! :)                                        ####
####        When you'll have finished work, MUST call destroyList() ####
######################################################################*/

List* createList ();
void destroyList (List* list);
void destroyOnlyList (List* list);
bool isEmpty (List* list);
ListNode* getFront (List* list);
void addFront (List* list, void* node);
void removeFront (List* list);
void removeKey (List* list, string key);
ListNode* searchList (List* list, string key);


/*######################################################################
####                       Huffman Code                             ####
####                                                                ####
#### Usage: 1. def. List* list=createList();                        ####
####        2. def. Tree* tree=createTree();                        ####
####        3.1. To compress,                                       ####
####             def. str[BUF], *bit, *treeStr(char), bit_len(int)  ####
####             Compression(list,tree,str,&bit,&treeStr,&bit_len)  ####
####        3.1. To decompress,                                     ####
####             def. *str, bit[BUF], *treeStr(char), bit_len(int)  ####
####             Decompression(tree,bit,&str,treeStr,bit_len)       ####
####        4.1. 3.1 => convert str to bit, you can use bit         ####
####        4.2. 3.2 => convert bit to str, you can use str         ####
######################################################################*/

// Buffer constant
#define HUFFMAN_BUF_SIZE 50000
#define HUFFMAN_CODE_BUF 17

Tree* createTree ();

// Compression의 리턴 값은 코드의 길이로 압축후 용량에 대해 나타내기 위함이다.
int  Compression (List* list, Tree* tree, char* buf, char** ret, char** ret_treeStr, int* ret_len);
void Decompression (Tree* tree, char* buf, char** ret, char* treeStr, int bit_len);
void Huffman_FreePointer(List* list, Tree* tree, char* treeStr, char* buf);

#endif

