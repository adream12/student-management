﻿#ifndef _PROCESS_H_
#define _PROCESS_H_



/*######################################################################
####                         A D M I N                              ####
######################################################################*/

void Admin_add (int mode);
void Admin_mod (int mode);
void Admin_del (int mode);
void Admin_view(int mode);

/*######################################################################
####                       T E A C H E R                            ####
######################################################################*/

void Teacher_InputScore ();
void Teacher_ClassScoreView();
void Teacher_GradeView ();
void Teacher_modInfo();


/*######################################################################
####                        S T U D E N T                           ####
######################################################################*/

void Student_viewScore();
void Student_modInfo();

#endif