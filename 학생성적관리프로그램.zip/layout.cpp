﻿#include "common.h"

void layout_head()
{
    //system("clear");    // in linux
    system("cls");      // in window

    cout << "=====================================================================" << endl;
    cout << "==                                                                 ==" << endl;
    cout << "==                   성 적 관 리  프 로 그 램                      ==" << endl;
    cout << "==                                                                 ==" << endl;
    cout << "=====================================================================" << endl;
    if (Current_User != NULL)
        cout << "[ " << ((Primary_info*) Current_User)->getName() << "님 접속중 ]" << endl; 
    cout << endl;
}

void layout_tail()
{

}
