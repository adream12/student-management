﻿#include "common.h"
#include "process.h"
#include "file.h"
#include <iomanip>


/*######################################################################
####                                                                ####
####                    Common function & Macro                     ####
####                                                                ####
######################################################################*/

// Check if user want to canle
#define IsCancle(c)                         { if (ChkCancle(c)) { return; }}
#define IsCancle_list(c,list)               { if (ChkCancle(c)) { destroyOnlyList(list); return; }}
#define IsCancle_obj(c,obj)                 { if (ChkCancle(c)) { if(obj) delete obj; return; }}
#define IsCancle_obj_tab(c,obj,tab)         { if (ChkCancle(c)) { if(obj) delete obj; if(tab) delete tab; return; }}
#define IsDuplicate(list,c)                 { if(ChkDuplication(list,c) == true) { return; }}
#define IsDuplicate_obj(list,c,obj)         { if(ChkDuplication(list,c) == true) { if(obj) delete obj; return; }}
#define IsDuplicate_obj_tab(list,c,obj,tab) { if(ChkDuplication(list,c) == true) { if(obj) delete obj; if(tab) delete tab; return; }}



static bool ChkCancle (int in)
{
    return (in == -1) ? true : false;
}

static bool ChkCancle (string in)
{
    return (in.compare("-1") == 0) ? true : false;
}

// swap function
static void _swap(void** first, void** second)
{
    void* temp = *first;
    *first = *second;
    *second = temp;
}

static bool ChkDuplication (List* list, string key)
{
    if (searchList (list, key) != NULL)
    {
        cout << endl;
        cout << "  이미 존재하는 ID 혹은 이름입니다." << endl;

        PAUSE();

        return true;
    }

    return false;
}

static string Fill_Buffer ()
{
    string buffer = "";

    // Fill buffer with Teacher class contents
    ListNode* node = Tea_list->front;
    
    while (node != NULL)
    {
        Teacher_info *data = (Teacher_info*) node->data;

        buffer += (to_string((long double) data->getMode()) + '/');
        buffer += (data->getIDcode() + '/');
        buffer += (data->getName() + '/');
        buffer += (data->getPassword() + '/');
        buffer += (data->getBirth() + '/');
        buffer += (to_string((long double) data->getGrade()) + '/');
        buffer += (to_string((long double) data->getClass()) + '\n');

        node = node->next;
    }


    // Fill buffer with Student class contents
    Avl_FillBuffer (Stu_avl, &buffer);

    return buffer;
}


/*######################################################################
####                                                                ####
####                         A D M I N                              ####
####                                                                ####
######################################################################*/

// 추가 메뉴
void Admin_add (int mode)
{
    string buffer;

    cout << "입력을 취소하시려면 -1 을 입력하세요.\n" << endl;

    switch (mode)
    {
        // Teacher mode
        case TEACHER:
            {
                Teacher_info *obj = new Teacher_info;
                Teacher_info *data = NULL;
                string in_str;
                int    in_int;

                // Input IDcode
                cout << "* 교번을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsCancle_obj(in_str, obj);                 // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료
                obj -> setIDcode(in_str);
                IsDuplicate_obj(Tea_list, in_str, obj);    // Check whether key is duplicated   

                // Input name
                cout << "* 이름을 입력하세요.(띄어쓰기 없이 입력)" << endl;
                cout << "  입력 : ";
                getchar();
                getline(cin, in_str);
                IsCancle_obj(in_str, obj);
                obj -> setName(in_str);
                IsDuplicate_obj(Tea_list, in_str, obj);

                // Input birth
                cout << "* 생년월일을 입력하세요.(YYMMDD)" << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsCancle_obj(in_str, obj);
                obj -> setBirth (in_str);
                obj -> setPassword(in_str);

                // Input Class
                cout << "* 선생님이 담당하는 학년을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int;
                IsCancle_obj(in_int, obj);
                obj -> setGrade(in_int);

                // Input Class
                cout << "* 선생님이 담당하는 반을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int;
                IsCancle_obj(in_int, obj);
                obj -> setClass(in_int);

                // insert each information to each list
                addFront(Tea_list, obj);
                
                data = (Teacher_info*) getFront(Tea_list)->data;

                cout << endl;
                cout << "=======================================================" << endl;
                cout << "   교번 : " << data->getIDcode() << endl;
                cout << "   이름 : " << data->getName() << endl;
                cout << "   생년월일 : " << data->getBirth() << endl;
                cout << "   학년 : " << data->getGrade() << endl;
                cout << "   반 : " << data->getClass() << endl;
                cout << endl;
                cout << "   * ID는 교번 / 초기 비밀번호는 생년월일로 설정됩니다." << endl;
                cout << "=======================================================" << endl;
                cout << "입력이 완료되었습니다." << endl;
              
                PAUSE();

                break;
            }
        
        // Student mode
        case STUDENT:
            {
                Student_info *obj = new Student_info;
                Search_table *tab = new Search_table;
                Student_info *data = NULL;
                string in_str;
                int    in_int;

                // Input IDcode
                cout << "* 학번을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsDuplicate_obj_tab (SearchTable_list, in_str, obj, tab);    // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료
                obj -> setIDcode (in_str);
                tab -> IDcode = in_str;
                IsDuplicate_obj_tab (SearchTable_list, in_str, obj, tab);    // Check whether key is duplicated   

                // Input name
                cout << "* 이름을 입력하세요.(띄어쓰기 없이 입력)" << endl;
                cout << "  입력 : ";
                getchar();
                getline(cin, in_str);
                IsCancle_obj_tab (in_str, obj, tab);
                obj -> setName (in_str);
                tab -> name = in_str;
                IsDuplicate_obj_tab (SearchTable_list, in_str, obj, tab);

                // Input birth
                cout << "* 생년월일을 입력하세요.(YYMMDD)" << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsCancle_obj_tab(in_str, obj, tab);
                obj -> setBirth (in_str);
                obj -> setPassword (in_str);

                // Input grade
                cout << "* 학생의 학년을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int;
                IsCancle_obj_tab (in_int, obj, tab);
                obj -> setGrade (in_int);

                // Input Class
                cout << "* 학생의 반을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int;
                IsCancle_obj_tab (in_int, obj, tab);
                obj -> setClass (in_int);

                // insert each information to each list
                Avl_Insert (&Stu_avl, obj);
                addFront (SearchTable_list, tab);
                
                data = Avl_Search(Stu_avl, ((Search_table*)getFront(SearchTable_list)->data)->IDcode)->data;
                
                cout << endl;
                cout << "=======================================================" << endl;
                cout << "   학번 : " << data->getIDcode() << endl;
                cout << "   이름 : " << data->getName() << endl;
                cout << "   생년월일 : " << data->getBirth() << endl;
                cout << "   학년 : " << data->getGrade() << endl;
                cout << "   반 : " << data->getClass() << endl;
                cout << endl;
                cout << "   * ID는 학번 / 초기 비밀번호는 생년월일로 설정됩니다." << endl;
                cout << "=======================================================" << endl;
                cout << "입력이 완료되었습니다." << endl;
              
                PAUSE();
                break;
            }
    }

    // Fill the buffer
    buffer = Fill_Buffer ();

    // write File
    writeFile(buffer);
}

// 수정 메뉴
void Admin_mod (int mode)
{
    string buffer;

    cout << "입력을 취소하시려면 -1 을 입력하세요.\n" << endl;

    switch (mode)
    {
        // Teacher mode
        case TEACHER:
            {
                Teacher_info *data = NULL;
                ListNode *listnode = NULL;
                string in_str;
                string in_str_name;
                string in_int_birth;
                int    in_int_grade;
                int    in_int_class;
                string in_str_password;

                // Search object
                cout << "* 수정할 교사의 교번 또는 이름을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsCancle(in_str);   // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료
                
                if ((listnode = searchList(Tea_list, in_str)) == NULL)
                {
                    cout << endl;
                    cout << "  해당 교사가 존재하지 않습니다." << endl;

                    PAUSE();
                    return;
                }

                data = (Teacher_info*) listnode->data;

                cout << endl;
                cout << "=======================================================" << endl;
                cout << " * 검색하신 교사의 정보입니다." << endl;
                cout << "   교번 : " << data->getIDcode() << " (수정 불가)" << endl;
                cout << "   이름 : " << data->getName() << endl;
                cout << "   생년월일 : " << data->getBirth() << endl;
                cout << "   학년 : " << data->getGrade() << endl;
                cout << "   반 : " << data->getClass() << endl;
                cout << "=======================================================" << endl;
                cout << endl;

                // Input name
                cout << "* 수정할 이름을 입력하세요.(띄어쓰기 없이 입력)" << endl;
                cout << "  입력 : ";
                getchar();
                getline(cin, in_str_name);
                IsCancle(in_str_name);
                if (data->getName() != in_str_name)
                    IsDuplicate(Tea_list, in_str_name); 

                // Input birth
                cout << "* 수정할 생년월일을 입력하세요.(YYMMDD)" << endl;
                cout << "  입력 : ";
                cin >> in_int_birth;
                IsCancle(in_int_birth);
                
                // Input Class
                cout << "* 수정할 학년을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int_grade;
                IsCancle(in_int_grade);

                // Input Class
                cout << "* 수정할 반을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int_class;
                IsCancle(in_int_class);

                // Input password
                cout << "* 수정할 비밀번호를 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str_password;
                IsCancle(in_str_password);

                // set value
                data -> setName(in_str_name);
                data -> setBirth (in_int_birth);
                data -> setGrade(in_int_grade);
                data -> setClass(in_int_class);
                data -> setPassword(in_str_password);

                cout << "수정이 완료되었습니다." << endl;

                PAUSE();

                break;
            }
        
        // Student mode
        case STUDENT:
            {
                Student_info *data = NULL;
                AvlNode *avlnode = NULL;
                string in_str;
                string in_str_name;
                string in_int_birth;
                int    in_int_grade;
                int    in_int_class;
                string in_str_password;

                // Search object
                cout << "* 수정할 학생의 교번 또는 이름을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsCancle(in_str);   // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료
                
                if ((avlnode = Avl_Search(Stu_avl, in_str)) == NULL)
                {
                    cout << endl;
                    cout << "  해당 학생이 존재하지 않습니다." << endl;

                    PAUSE();
                    return;
                }

                data = (Student_info*) avlnode->data;

                cout << endl;
                cout << "=======================================================" << endl;
                cout << " * 검색하신 학생의 정보입니다." << endl;
                cout << "   학번 : " << data->getIDcode() << " (수정 불가)" << endl;
                cout << "   이름 : " << data->getName() << endl;
                cout << "   생년월일 : " << data->getBirth() << endl;
                cout << "   학년 : " << data->getGrade() << endl;
                cout << "   반 : " << data->getClass() << endl;
                cout << "=======================================================" << endl;
                cout << endl;

                // Input name
                cout << "* 수정할 이름을 입력하세요.(띄어쓰기 없이 입력)" << endl;
                cout << "  입력 : ";
                getchar();
                getline(cin, in_str_name);
                IsCancle(in_str_name);
                if (data->getName() != in_str_name)
                    IsDuplicate(SearchTable_list, in_str_name); 

                // Input birth
                cout << "* 수정할 생년월일을 입력하세요.(YYMMDD)" << endl;
                cout << "  입력 : ";
                cin >> in_int_birth;
                IsCancle(in_int_birth);
                
                // Input Class
                cout << "* 수정할 학년을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int_grade;
                IsCancle(in_int_grade);

                // Input Class
                cout << "* 수정할 반을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_int_class;
                IsCancle(in_int_class);
                
                // Input password
                cout << "* 수정할 비밀번호를 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str_password;
                IsCancle(in_str_password);

                // set value
                data -> setName(in_str_name);
                data -> setBirth (in_int_birth);
                data -> setGrade(in_int_grade);
                data -> setClass(in_int_class);
                data -> setPassword(in_str_password);

                // Modify SearchTable_list value
                ((Search_table*)searchList(SearchTable_list, data->getIDcode())->data)->name = data->getName();

                cout << "수정이 완료되었습니다." << endl;

                PAUSE();
                break;
            }
    }

    // Fill the buffer
    buffer = Fill_Buffer ();
    
    // write File
    writeFile(buffer);
}

// 삭제 메뉴
void Admin_del (int mode)
{
    string buffer;

    cout << "입력을 취소하시려면 -1 을 입력하세요.\n" << endl;

    switch (mode)
    {
        // Teacher mode
        case TEACHER:
            {
                Teacher_info *data = NULL;
                ListNode *listnode = NULL;
                string in_str;
                int mode;

                // Search object
                cout << "* 삭제할 교사의 교번 또는 이름을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsCancle(in_str);   // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료
                
                if ((listnode = searchList(Tea_list, in_str)) == NULL)
                {
                    cout << endl;
                    cout << "  해당 교사가 존재하지 않습니다." << endl;

                    PAUSE();
                    return;
                }

                data = (Teacher_info*)listnode->data;

                cout << endl;
                cout << "=======================================================" << endl;
                cout << " * 검색하신 교사의 정보입니다." << endl;
                cout << "   교번 : " << data->getIDcode() << endl;
                cout << "   이름 : " << data->getName() << endl;
                cout << "   생년월일 : " << data->getBirth() << endl;
                cout << "   학년 : " << data->getGrade() << endl;
                cout << "   반 : " << data->getClass() << endl;
                cout << "=======================================================" << endl;
                cout << endl;

                cout << "* 정말 삭제하시겠습니까?" << endl;
                cout << "  1: YES" << endl;
                cout << "  2: NO" << endl;
                cin >> mode;

                switch (mode)
                {
                    case YES:
                        {
                            string key = data->getIDcode();
                            
                            removeKey (Tea_list, key);
                            cout << endl;
                            cout << "삭제가 완료되었습니다." << endl;

                            break;
                        }

                    case NO:
                        {
                            cout << endl;
                            cout << "  삭제를 취소합니다." << endl;
                            return;
                        }
                }

                PAUSE();

                break;
            }
        
        // Student mode
        case STUDENT:
            {
                Student_info *data = NULL;
                AvlNode *avlnode = NULL;
                string in_str;
                int mode;

                // Search object
                cout << "* 삭제할 학생의 학번 또는 이름을 입력하세요." << endl;
                cout << "  입력 : ";
                cin >> in_str;
                IsCancle(in_str);   // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료
                
                if ((avlnode = Avl_Search(Stu_avl, in_str)) == NULL)
                {
                    cout << endl;
                    cout << "  해당 학생이 존재하지 않습니다." << endl;

                    PAUSE();
                    return;
                }

                data = (Student_info*)avlnode->data;

                cout << endl;
                cout << "=======================================================" << endl;
                cout << " * 검색하신 학생의 정보입니다." << endl;
                cout << "   교번 : " << data->getIDcode() << endl;
                cout << "   이름 : " << data->getName() << endl;
                cout << "   생년월일 : " << data->getBirth() << endl;
                cout << "   학년 : " << data->getGrade() << endl;
                cout << "   반 : " << data->getClass() << endl;
                cout << "=======================================================" << endl;
                cout << endl;

                cout << "* 정말 삭제하시겠습니까?" << endl;
                cout << "  1: YES" << endl;
                cout << "  2: NO" << endl;
                cin >> mode;

                switch (mode)
                {
                    case YES:
                        {
                            string key = data->getIDcode();
                            
                            Avl_Delete (&Stu_avl, key);
                            removeKey (SearchTable_list, key);
                            cout << endl;
                            cout << "삭제가 완료되었습니다." << endl;

                            break;
                        }

                    case NO:
                        {
                            cout << endl;
                            cout << "  삭제를 취소합니다." << endl;
                            return;
                        }
                }

                PAUSE();

                break;
            }
    }

    // Fill the buffer
    buffer = Fill_Buffer ();
    
    // write File
    writeFile(buffer);
}


// 전체 보기 메뉴
static void GradeClass_sortList (List *list)
{
    for (ListNode* i = list->front; i != NULL; i = i->next)
    {
        Primary_info *data_i = (Primary_info*) i->data;

        for (ListNode* j = list->front; j != NULL; j = j->next)
        {
            Primary_info *data_j = (Primary_info*) j->data;

            if ((data_i->getGrade() * 10) + data_i->getClass() < (data_j->getGrade() * 10) + data_j->getClass())
                _swap(&i->data, &j->data);
        }
    }
}

static void View_info (List *data, int mode)
{
    string mode_str;

    switch (mode)
    {
        case TEACHER:
            mode_str = "선생님";
            break;

        case STUDENT:
            mode_str = "학생";
            break;
    }

    cout << endl;
    cout << "-----------------------------------------------------------------------" << endl;
    cout << endl;

    for (ListNode* i = data->front; i != NULL; i = i->next)
    {
        Primary_info *data = (Primary_info*) i->data;

        cout << " [ ";
        cout << data->getGrade() << "학년 " 
                << data->getClass() << "반 ]"
                << "  "
                << data->getName() << mode_str << " (" << data->getIDcode() << ") " << endl;
        cout << "             " 
                << " * 생년월일: " << data->getBirth()
                << " | 비밀번호: " << data->getPassword() << endl;
        cout << endl;
    }
    cout << "-----------------------------------------------------------------------" << endl;

}

void Admin_view(int mode)
{

    switch (mode)
    {
        // Teacher mode
        case TEACHER:
            {
                // 학년, 반 순서대로 소팅
                GradeClass_sortList (Tea_list);

                // 실제 출력 부분
                View_info (Tea_list, mode);

                PAUSE();

                break;
            }
        
        // Student mode
        case STUDENT:
            {
                List *list_data = createList();

                // 트리에서 모든 데이터를 리스트로 가져옴
                Avl_Search_All (Stu_avl, list_data, NULL, ALL_INFO);

                // 학년, 반 순서대로 소팅
                GradeClass_sortList (list_data);
                
                // 실제 출력 부분
                View_info (list_data, mode);
                
                // Deallocate list
                destroyOnlyList (list_data);

                PAUSE();

                break;
            }
    }
}


/*######################################################################
####                                                                ####
####                       T E A C H E R                            ####
####                                                                ####
######################################################################*/

static void Rank_sortList (List *list, int mode)
{
    for (ListNode* i = list->front; i != NULL; i = i->next)
        for (ListNode* j = list->front; j != NULL; j = j->next)
            if (((Student_info*)i->data)->getScoreAvg() > ((Student_info*)j->data)->getScoreAvg())
                _swap(&i->data, &j->data);
    
    int rank = 1;

    if (mode == GRADE_CLASS)
        for (ListNode* i = list->front; i != NULL; i = i->next, rank++)
            ((Student_info*)i->data)->setClassRank(rank);

    else if (mode == GRADE)
        for (ListNode* i = list->front; i != NULL; i = i->next, rank++)
            ((Student_info*)i->data)->setEntireRank(rank);
}

static void View_Score (List *list)
{
    Student_info* data = NULL;

    cout << endl;
    cout << "======================================================================" << endl;
    cout << " * " << ((Teacher_info*)Current_User)->getGrade() << "학년 "
        << ((Teacher_info*)Current_User)->getClass() << "반 학생들의 정보입니다." << endl;
    cout << "   name   |Kor|Eng|Mat|His|Sci|Soc|Mus|Phy|Com|Fre|  Tot|  Avg|Cla|Gra" << endl;

    // Class's student info
    for (ListNode* cur = list->front; cur != NULL; cur = cur ->next)
    {
        data = (Student_info*) cur->data;

        cout << setw(9) << data->getName() << " |" ;

        for (int i = 0; i < TOTAL_SUBJECT; i++)
            cout << setw(3) << data->getScore(i) << "|" ;
        
        cout << setw(5) << data->getScoreSum() << "|" 
             << setw(5) << data->getScoreAvg() << "|" 
             << setw(3) << data->getClassRank() << "|" 
             << setw(3) << data->getEntireRank() << endl;
    }

    cout << "======================================================================" << endl;
    cout << endl;
}

// 점수 입력하기
void Teacher_InputScore ()
{
    string buffer;
    List *list_data = createList();
    Student_info* data = NULL;

    Avl_Search_All (Stu_avl, list_data, (Primary_info*) Current_User, GRADE_CLASS);

    // 학생들 점수판 출력
    View_Score (list_data);

    cout << "입력을 취소하시려면 -1 을 입력하세요.\n" << endl;
    

    string in_str;
    int in_int_score[TOTAL_SUBJECT];
    ListNode* cur = NULL;

    // Search object
    cout << "* 점수를 입력할 학생의 이름을 입력하세요." << endl;
    cout << "  입력 : ";
    cin >> in_str;
    IsCancle_list (in_str, list_data);   // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료
    
    for (cur = list_data->front; cur != NULL; cur = cur ->next)
    {
        data = (Student_info*) cur->data;

        if (in_str == data->getName())
            break;
    }
    if (cur == NULL)
    {
        cout << endl;
        cout << "  해당 학생이 존재하지 않습니다." << endl;

        PAUSE();
        return;
    }

    // Input score
    cout << "* 국어 : ";
    cin >> in_int_score[KOREA];
    IsCancle_list (in_int_score[KOREA], list_data);   // -1이 들어왔는지 체크하는 매크로, -1이면 객체 할당해제하고 종료

    cout << "* 영어 : ";
    cin >> in_int_score[ENGLISH];
    IsCancle_list (in_int_score[ENGLISH], list_data);

    cout << "* 수학 : ";
    cin >> in_int_score[MATH];
    IsCancle_list (in_int_score[MATH], list_data);

    cout << "* 국사 : ";
    cin >> in_int_score[HISTORY];
    IsCancle_list (in_int_score[HISTORY], list_data);

    cout << "* 과학 : ";
    cin >> in_int_score[SCIENCE];
    IsCancle_list (in_int_score[SCIENCE], list_data);

    cout << "* 사회 : ";
    cin >> in_int_score[SOCIAL];
    IsCancle_list (in_int_score[SOCIAL], list_data);

    cout << "* 음악 : ";
    cin >> in_int_score[MUSIC];
    IsCancle_list (in_int_score[MUSIC], list_data);

    cout << "* 체육 : ";
    cin >> in_int_score[PHYSICAL];
    IsCancle_list (in_int_score[PHYSICAL], list_data);

    cout << "* 컴퓨터 : ";
    cin >> in_int_score[COMPUTER];
    IsCancle_list (in_int_score[COMPUTER], list_data);

    cout << "* 프랑스어 : ";
    cin >> in_int_score[FRENCH];
    IsCancle_list (in_int_score[FRENCH], list_data);

    // set score
    for (int i = 0; i < TOTAL_SUBJECT; i++)
        data->setScore(in_int_score[i], i);

    // calculate total score & average
    data->calScore();

    // calculate class rank
    Rank_sortList(list_data, GRADE_CLASS);

    // calculate entire rank
    List *list_rank = createList();
    Avl_Search_All (Stu_avl, list_rank, (Primary_info*) Current_User, GRADE);
    Rank_sortList(list_rank, GRADE);

    cout << "총점 : " << data->getScoreSum() << endl;
    cout << "평균 : " << data->getScoreAvg() << endl;
    cout << "반 등수 : " << data->getClassRank() << endl;
    cout << "전교 등수 : " << data->getEntireRank() << endl;

    cout << "입력이 완료되었습니다." << endl;
    
    PAUSE();
    
    // Deallocate list
    destroyOnlyList (list_data);
    destroyOnlyList (list_rank);

    // Fill the buffer
    buffer = Fill_Buffer ();
    
    // write File
    writeFile(buffer);
}


static void View_GradeAvg(List* list, int Class)
{
    Student_info *data = NULL;

    double class_avgSum = 0;
    int    student_num = 0;

    for (ListNode* cur = list->front; cur != NULL; cur = cur->next)
    {
        data = (Student_info*)cur->data;

        if (data->getClass() == Class)
        {
            class_avgSum += data->getScoreAvg();
            student_num++;
        }
    }

    cout << class_avgSum / student_num;
}

// 반 점수 보기
void Teacher_ClassScoreView()
{
    List *list_data = createList();

    Avl_Search_All (Stu_avl, list_data, (Primary_info*) Current_User, GRADE_CLASS);
    View_Score(list_data);

    cout << endl;
    cout << "                                                     "
         << "반 평균 : " ;
    View_GradeAvg(list_data, ((Primary_info*)Current_User) -> getClass());

    PAUSE();

    // Deallocate list
    destroyOnlyList (list_data);
}


// 학년 반별 평균 보기
void Teacher_GradeView()
{
    List *list_data = createList();
    int grade_info;

    Avl_Search_All (Stu_avl, list_data, (Primary_info*) Current_User, GRADE);

    cout << "  * "<< (grade_info =((Primary_info*)Current_User)->getGrade()) << "학년 반별 평균입니다." << endl;

    switch (grade_info)
    {
        case 1:
            for (int i = 1; i <= FIRST_GRADE; i++)
            {
                cout << "  " << i << "반 평균: " ;

                View_GradeAvg (list_data, i);
    
                cout << endl;
            }
            break;
            
        case 2:
            for (int i = 1; i <= SECOND_GRADE; i++)
            {
                cout << "  " << i << "반 평균: " ;

                View_GradeAvg (list_data, i);
    
                cout << endl;
            }
            break;

        case 3:
            for (int i = 1; i <= THIRD_GRADE; i++)
            {
                cout << "  " << i << "반 평균: " ;

                View_GradeAvg (list_data, i);
    
                cout << endl;
            }
            break;
    }

    PAUSE();

    // Deallocate list
    destroyOnlyList (list_data);
}


// 교사 정보 수정하기
void Teacher_modInfo()
{
    string buffer;
    Teacher_info *data = (Teacher_info*) Current_User;
    string in_str;
    string in_int_birth;
    string in_str_password;

    
    cout << endl;
    cout << "=======================================================" << endl;
    cout << " * " << data->getName() << "님의 정보입니다." << endl;
    cout << "   교번 : " << data->getIDcode() << endl;
    cout << "   이름 : " << data->getName() << endl;
    cout << "   생년월일 : " << data->getBirth() << endl;
    cout << "   학년 : " << data->getGrade() << endl;
    cout << "   반 : " << data->getClass() << endl;
    cout << "=======================================================" << endl;
    cout << endl;

    cout << "입력을 취소하시려면 -1 을 입력하세요.\n" << endl;

    // Input birth
    cout << "* 수정할 생년월일을 입력하세요.(YYMMDD)" << endl;
    cout << "  입력 : ";
    cin >> in_int_birth;
    IsCancle(in_int_birth);

    // Input password
    cout << "* 수정할 비밀번호를 입력하세요." << endl;
    cout << "  입력 : ";
    cin >> in_str_password;
    IsCancle(in_str_password);

    // set value
    data -> setBirth (in_int_birth);
    data -> setPassword(in_str_password);

    cout << "수정이 완료되었습니다." << endl;

    PAUSE();

    // Fill the buffer
    buffer = Fill_Buffer ();
    
    // write File
    writeFile(buffer);
}


/*######################################################################
####                                                                ####
####                        S T U D E N T                           ####
####                                                                ####
######################################################################*/


void Student_viewScore()
{
    Student_info *data = (Student_info*) Current_User;

    cout << endl;
    cout << " * " << data->getName() << "님의 성적표입니다." << endl;
    cout << "   확인하시려면 엔터키를 눌러주세요. " << endl;
    
    PAUSE();
    
    cout << "  Kor|Eng|Mat|His|Sci|Soc|Mus|Phy|Com|Fre|" << endl;
    cout << "  ----------------------------------------" << endl;
    cout << "  ";
    for (int i = 0; i < TOTAL_SUBJECT; i++)
        cout << setw(3) << data->getScore(i) << "|" ;

    cout << endl;
    cout << endl;
    cout << endl;

    cout << "                               총점 : " << data->getScoreSum() << endl;
    cout << "                               평균 : " << data->getScoreAvg() << endl;
    cout << "                            반 등수 : " << data->getClassRank() << endl;
    cout << "                          전교 등수 : " << data->getEntireRank() << endl;

    PAUSE();

}


// 학생 정보 수정하기
void Student_modInfo()
{
    string buffer;
    Student_info *data = (Student_info*) Current_User;
    string in_str;
    string in_int_birth;
    string in_str_password;

    
    cout << endl;
    cout << "=======================================================" << endl;
    cout << " * " << data->getName() << "님의 정보입니다." << endl;
    cout << "   학번 : " << data->getIDcode() << endl;
    cout << "   이름 : " << data->getName() << endl;
    cout << "   생년월일 : " << data->getBirth() << endl;
    cout << "   학년 : " << data->getGrade() << endl;
    cout << "   반 : " << data->getClass() << endl;
    cout << "=======================================================" << endl;
    cout << endl;

    cout << "입력을 취소하시려면 -1 을 입력하세요.\n" << endl;

    // Input birth
    cout << "* 수정할 생년월일을 입력하세요.(YYMMDD)" << endl;
    cout << "  입력 : ";
    cin >> in_int_birth;
    IsCancle(in_int_birth);

    // Input password
    cout << "* 수정할 비밀번호를 입력하세요." << endl;
    cout << "  입력 : ";
    cin >> in_str_password;
    IsCancle(in_str_password);

    // set value
    data -> setBirth (in_int_birth);
    data -> setPassword(in_str_password);

    // Modify SearchTable_list value
    ((Search_table*)searchList(SearchTable_list, data->getIDcode())->data)->name = data->getName();

    cout << "수정이 완료되었습니다." << endl;

    PAUSE();

    // Fill the buffer
    buffer = Fill_Buffer ();
    
    // write File
    writeFile(buffer);
}

