﻿#ifndef _MENU_H_
#define _MENU_H_


// menu mode
#define MAIN_MENU   1
#define SUB_MENU    2

// system menu
#define BACK    0
#define EXIT    0

// admin menu
#define ADMIN_ADD     1
#define ADMIN_MODIFY  2
#define ADMIN_DELETE  3
#define ADMIN_VIEW    4

// teacher menu
#define INPUT_SCORE         1
#define VIEW_SCORE          2
#define TEACHER_MOD_INFO    3

#define CLASS_SCORE_VIEW    1
#define GRADE_AVG_VIEW      2


// student menu
#define STUDENT_VIEW_SCORE  1
#define STUDENT_MOD_INFO    2

void admin_menu();
void teacher_menu();
void student_menu();

#endif
