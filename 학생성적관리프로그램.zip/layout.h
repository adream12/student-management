﻿#ifndef _LAYOUT_H_
#define _LAYOUT_H_

void layout_head();
void layout_tail();

#endif
