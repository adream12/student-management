﻿#include "common.h"
#include "menu.h"
#include "process.h"

/*######################################################################
####                        admin menu                              ####
######################################################################*/

/*
    이    름 : print_admiin_menu (int mode)
    역    할 : 메인메뉴/서브메뉴의 내용을 화면에 출력함
    파라미터 : 메인메뉴인지 서브메뉴인지 구별할 수 있는 mode값을 받음
    반 환 값 : void
    기    타 : 내부용 함수 (static)
*/
static void print_admin_menu (int mode)
{
    switch (mode)
    {
        case MAIN_MENU:
            cout << "1: 교사 관리" << endl;
            cout << "2: 학생 관리" << endl;
            cout << "0: 종료" << endl;
            break;

        case SUB_MENU:
            cout << "1: 추가" << endl;
            cout << "2: 수정" << endl;
            cout << "3: 삭제" << endl;
            cout << "4: 전체 보기" << endl;
            cout << "0: 뒤로 가기" << endl;
            break;
    }
    cout << endl;
    cout << "입력 : ";
}

/*
   이    름 : admin_submenu (int mode)
   역    할 : 관리자 모드의 서브메뉴 관리 (프로세스 함수 호출)
   파라미터 : 교사인지 학생인지 구분할 수 있는 mode 값을 받아서 프로세스 함수로 넘겨줌
   반 환 값 : void
   기    타 : 내부용 함수 (static)
*/
static void admin_submenu(int mode)
{
    int sub_menu;
    
    while (layout_head(), print_admin_menu(SUB_MENU), cin >> sub_menu, sub_menu != BACK)
    {
        switch (sub_menu)
        {
            case ADMIN_ADD:
                // predicted function prototype
                // void admin_add(int mode);
                layout_head();
                Admin_add(mode);
                break;

            case ADMIN_MODIFY:
                layout_head();
                Admin_mod(mode);
                break;

            case ADMIN_DELETE:
                layout_head();
                Admin_del(mode);
                break;

            case ADMIN_VIEW:
                layout_head();
                Admin_view(mode);
                break;

            default:
                cout << "잘 못 누르셨습니다." << endl;
                cout << "다시 한 번 선택해 주세요." << endl;
                PAUSE();
                break;
        }
    }
}

/*
   이    름 : admin_menu ()
   역    할 : 관리자 모드의 메뉴 관리
   파라미터 : 없음
   반 환 값 : void
   기    타 : while문을 통해 Loop
*/
void admin_menu()
{
    int main_menu;

    while (layout_head(), print_admin_menu(MAIN_MENU), cin >> main_menu, main_menu != EXIT)
    {
        switch (main_menu)
        {
            case TEACHER:
                admin_submenu(TEACHER);
                break;

            case STUDENT:
                admin_submenu(STUDENT);
                break;

            default:
                cout << "잘 못 누르셨습니다." << endl;
                cout << "다시 한 번 선택해 주세요." << endl;
                PAUSE();
                break;
        }
    }
}

/*######################################################################
####                       teacher menu                             ####
######################################################################*/

/*
    이    름 : print_teacher_menu (int mode)
    역    할 : 메인메뉴/서브메뉴의 내용을 화면에 출력함
    파라미터 : 메인메뉴인지 서브메뉴인지 구별할 수 있는 mode값을 받음
    반 환 값 : void
    기    타 : 내부용 함수 (static)
*/
static void print_teacher_menu (int mode)
{
    switch (mode)
    {
        case MAIN_MENU:
            cout << "1: 점수 입력" << endl;
            cout << "2: 점수 확인" << endl;
            cout << "3: 개인정보수정" << endl;
            cout << "0: 종료" << endl;
            break;

        case SUB_MENU:
            cout << "1: "<< ((Teacher_info*)Current_User)->getGrade() << "학년 "
                << ((Teacher_info*)Current_User)->getClass() << "반의 점수 확인" << endl;
            cout << "2: "<< ((Teacher_info*)Current_User)->getGrade() 
                << "학년 반별 평균 확인" << endl;
            cout << "0: 뒤로 가기" << endl;
            break;
    }
    cout << endl;
    cout << "입력 : ";
}

/*
   이    름 : Teacher_submenu ()
   역    할 : 교사 모드의 서브메뉴 관리 (프로세스 함수 호출)
   파라미터 : 없음
   반 환 값 : void
   기    타 : 내부용 함수 (static)
*/
static void Teacher_submenu()
{
    int sub_menu;
    
    while (layout_head(), print_teacher_menu(SUB_MENU), cin >> sub_menu, sub_menu != BACK)
    {
        switch (sub_menu)
        {
            case CLASS_SCORE_VIEW:
                layout_head();
                Teacher_ClassScoreView();
                break;

            case GRADE_AVG_VIEW:
                layout_head();
                Teacher_GradeView();
                break;
                
            default:
                cout << "잘 못 누르셨습니다." << endl;
                cout << "다시 한 번 선택해 주세요." << endl;
                PAUSE();
                break;
        }
    }
}

/*
   이    름 : teacher_menu ()
   역    할 : 교사 모드의 메뉴 관리
   파라미터 : 없음
   반 환 값 : void
   기    타 : while문을 통해 Loop
*/
void teacher_menu()
{
    int main_menu;

    while (layout_head(), print_teacher_menu(MAIN_MENU), cin >> main_menu, main_menu != EXIT)
    {
        switch (main_menu)
        {
            case INPUT_SCORE:
                layout_head();
                Teacher_InputScore();
                break;

            case VIEW_SCORE:
                Teacher_submenu();
                break;

            case TEACHER_MOD_INFO:
                Teacher_modInfo();
                break;

            default:
                cout << "잘 못 누르셨습니다." << endl;
                cout << "다시 한 번 선택해 주세요." << endl;
                PAUSE();
                break;
        }
    }
}

/*######################################################################
####                       student menu                             ####
######################################################################*/


/*
    이    름 : print_student_menu ()
    역    할 : 메뉴의 내용을 화면에 출력함
    파라미터 : 없음
    반 환 값 : void
    기    타 : 내부용 함수 (static)
*/
static void print_student_menu ()
{
    cout << "1: 점수 확인" << endl;
    cout << "2: 개인정보수정" << endl;
    cout << "0: 종료" << endl;
    cout << endl;
    cout << "입력 : ";
}


/*
   이    름 : student_menu ()
   역    할 : 학생 모드의 메뉴 관리
   파라미터 : 없음
   반 환 값 : void
   기    타 : while문을 통해 Loop
*/
void student_menu()
{
    int main_menu;

    while (layout_head(), print_student_menu(), cin >> main_menu, main_menu != EXIT)
    {
        switch (main_menu)
        {
            case STUDENT_VIEW_SCORE:
                layout_head();
                Student_viewScore();
                break;

            case STUDENT_MOD_INFO:
                Student_modInfo();
                break;
                
            default:
                cout << "잘 못 누르셨습니다." << endl;
                cout << "다시 한 번 선택해 주세요." << endl;
                PAUSE();
                break;
        }
    }
}
