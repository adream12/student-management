﻿#ifndef _COMMON_H_
#define _COMMON_H_

#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>

#include "layout.h"

using namespace std;


// Define macro
#define PAUSE()         { while(getchar() != '\n'); getchar(); }  // 입력 버퍼를 지우고 잠시 멈추게 함


// DEBUG PRINT
// If you want to see debug print, set 1 or not set 0
#define DEBUG_PRINT     0
#define ERROR_TEST      0

// Mode
#define ADMIN       0
#define TEACHER     1
#define STUDENT     2
#define ERROR_MODE  3

#define YES     1
#define NO      2

#define GRADE           1
#define CLASS           2
#define GRADE_CLASS     3
#define ALL_INFO        4

#define FIRST_GRADE     8
#define SECOND_GRADE    4
#define THIRD_GRADE     4

// Subject (Score array index)
#define KOREA           0
#define ENGLISH         1
#define MATH            2
#define HISTORY         3
#define SCIENCE         4
#define SOCIAL          5
#define MUSIC           6
#define PHYSICAL        7
#define COMPUTER        8
#define FRENCH          9
#define TOTAL_SUBJECT   10  // total subject number

// Define class
// Primary infomation class
class Primary_info
{
public:
    int getMode ()
    {
        return mode;
    }

    void setName (string name)
    {
        this->name = name;
    }
    
    string getName ()
    {
        return name;
    }

    void setIDcode (string id)
    {
        this->IDcode = id;
    }

    string getIDcode ()
    {
        return IDcode;
    }

    void setPassword (string password)
    {
        this->password = password;
    }

    string getPassword ()
    {
        return password;
    }


    void setBirth (string birth)
    {
        this->birth = birth;
    }

    string getBirth ()
    {
        return birth;
    }
    
    void setGrade (int grade)
    {
        this->grade = grade;
    }

    int getGrade ()
    {
        return grade;
    }

    void setClass (int Class)
    {
        this->Class = Class;
    }

    int getClass ()
    {
        return Class;
    }

protected:
    int mode;
    string IDcode;      // length to be less than 10
    string name;
    string password;    // first of all, be Initailized birth.
    string birth;
    int grade;
    int Class;
};


// teacher class
class Teacher_info : public Primary_info
{
public:
    Teacher_info()
    {
        mode = TEACHER;
    }
};


// student class
class Student_info : public Primary_info
{
public:
    Student_info()
    {
        // initailize each variables
        mode = STUDENT;

        for (int i = 0 ; i < TOTAL_SUBJECT ; i++)
        {
            this->score[i] = 0;
        }

        score_sum   = 0;
        score_avg   = 0;
        class_rank  = 0;
        entire_rank = 0;
    }

    void setScore (int score, int subject)
    {
        this->score[subject] = score;
    }

    int getScore (int subject)
    {
        return score[subject];
    }

    // calculate total score & average
    void calScore ()
    {
        score_sum = 0;

        for (int i = 0 ; i < TOTAL_SUBJECT ; i++)
        {
            score_sum += score[i];
        }

        score_avg = (double) score_sum / TOTAL_SUBJECT;
    }

    void setScoreSum (int score_sum)
    {
        this->score_sum = score_sum;
    }

    int getScoreSum ()
    {
        return score_sum;
    }

    void setScoreAvg (double score_avg)
    {
        this->score_avg = score_avg;
    }

    double getScoreAvg ()
    {
        return score_avg;
    }

    void setClassRank (int class_rank)
    {
        this->class_rank = class_rank;
    }

    int getClassRank ()
    {
        return class_rank;
    }

    void setEntireRank (int entire_rank)
    {
        this->entire_rank = entire_rank;
    }

    int getEntireRank ()
    {
        return entire_rank;
    }

private:
    int score[10];
    int score_sum;
    double score_avg;
    int class_rank;
    int entire_rank;
};


#include "ds.h"


// Structure
typedef struct _search_table Search_table;
struct _search_table
{
    string IDcode;
    string name;
};

// Global variable
extern List    *Tea_list;
extern AvlNode *Stu_avl;
extern List    *SearchTable_list;
extern void    *Current_User;

#endif
