﻿#include "common.h"
#include "ds.h"


/*######################################################################
####                                                                ####
####                         AVL TREE                               ####
####                                                                ####
######################################################################*/

// LL Rotation
static AvlNode* LL_Rotation (AvlNode *parent)
{
    AvlNode *child = parent -> left;
    parent -> left = child -> right;
    child -> right = parent;

    return child;
}

// RR Rotation
static AvlNode* RR_Rotation (AvlNode *parent)
{
    AvlNode *child = parent -> right;
    parent -> right = child -> left;
    child -> left = parent;

    return child;
}

// RL Rotation
static AvlNode* RL_Rotation (AvlNode *parent)
{
    AvlNode *child = parent -> right;
    parent -> right = LL_Rotation (child);

    return RR_Rotation (parent);
}

// LR Rotation
static AvlNode* LR_Rotation (AvlNode *parent)
{
    AvlNode *child = parent -> left;
    parent -> left = RR_Rotation (child);

    return LL_Rotation (parent);
}


// get tree's height
static int GetHeight (AvlNode *node)
{
    int height = 0;

    if (node != NULL)
        height = 1 + max (GetHeight(node -> left), GetHeight(node -> right));

    return height;
}

// get balance value
static int GetBalance (AvlNode *node)
{
    if (node == NULL)
        return 0;

    return GetHeight(node -> left) - GetHeight(node -> right);
}

// make balance tree
static AvlNode* Make_BalanceTree (AvlNode **node)
{
    int height_diff = GetBalance(*node);

    if (height_diff > 1)                     // adjust left subtree
    {
        if(GetBalance((*node) -> left) > 0)
            *node = LL_Rotation(*node);

        else
            *node = LR_Rotation(*node);
    }

    else if (height_diff < -1)               // adjust right subtree
    {
        if(GetBalance((*node) -> right) < 0)
            *node = RR_Rotation(*node);

        else
            *node = RL_Rotation(*node);
    }

    return *node;
} 


// Insert node
AvlNode* Avl_Insert (AvlNode **root, Student_info *in)
{
    if (*root == NULL)
    {
        *root = new AvlNode;

        if(*root == NULL)
        {
            cout << "Error: Cann't Allocate Memory." << endl;
            exit(-1);
        }
        (*root) -> data = in;
        (*root) -> left = (*root) -> right = NULL;
    }

    else if (in -> getIDcode() < (*root) -> data -> getIDcode())
    {
        (*root) -> left = Avl_Insert (&((*root) -> left), in);
        (*root) = Make_BalanceTree (root);
    }

    else if (in -> getIDcode() > (*root) -> data -> getIDcode())
    {
        (*root) -> right = Avl_Insert (&((*root) -> right), in);
        (*root) = Make_BalanceTree (root);
    }

    else
    {
        cout << "Fail: Duplicate IDcode." << endl;
        return NULL;
    }

    return *root;
}


// Serach node (recursive function)
static AvlNode* Avl_Search_proc (AvlNode *node, string key)
{
    if (node == NULL)
        return NULL;

    if (key == node -> data -> getIDcode())
        return node;

    else if (key < node -> data -> getIDcode())
        return Avl_Search_proc (node->left, key);

    else
        return Avl_Search_proc (node -> right, key);
}


// Serach node
AvlNode* Avl_Search (AvlNode *node, string key)
{
    AvlNode* result_node = Avl_Search_proc (node, key);

    // Key를 학번으로 입력하여 한 번에 찾았을 때, (속도가 더 빠름)
    if (result_node)
        return result_node;

    // Key를 이름으로 입력해서 트리를 통해 찾지 못 했을 때,
    ListNode* cur = NULL;

    // Identify real_key to IDcode, althogh user search using name information
    for (cur = SearchTable_list->front; cur != NULL; cur = cur->next)
    {
#if DEBUG_PRINT
        cout << ((Search_table*)cur->data)->name << endl;
#endif

        if (((Search_table*)cur->data)->IDcode == key || ((Search_table*)cur->data)->name == key)
        {
            key = ((Search_table*)cur->data)->IDcode;
            break;
        }
    }

    // 이름 또한 존재하지 않을 때, (즉, 데이터가 없을 때)
    if (cur == NULL)
        return NULL;

    return Avl_Search_proc (node, key);    
}

// Serach All node and insert result to list
void Avl_Search_All (AvlNode *node, List *list, Primary_info* key, int mode)
{
    if (node == NULL)
        return;

    Avl_Search_All (node->left, list, key, mode);
    Avl_Search_All (node->right, list, key, mode);

    switch (mode)
    {
        case GRADE:
            {
                if (((Primary_info*) node->data)->getGrade() == key->getGrade())
                    addFront(list, node->data);
                break;
            }

        case CLASS:
            {
                if (((Primary_info*) node->data)->getClass() == key->getClass())
                    addFront(list, node->data);
                break;
            }

        case GRADE_CLASS:
            {
                if (((Primary_info*) node->data)->getGrade() == key->getGrade()
                    && ((Primary_info*) node->data)->getClass() == key->getClass())
                    addFront(list, node->data);
                break;
            }

        case ALL_INFO:
            {
                addFront(list, node->data);
            }
    }
}

static AvlNode* minValueNode (AvlNode* node)
{
    AvlNode* cur = node;
 
    /* loop down to find the leftmost leaf */
    while (cur->left != NULL)
        cur = cur->left;
 
    return cur;
}

void Avl_FillBuffer (AvlNode *node, string *buf)
{
    if (node == NULL)
        return;

//  노드->데이터는 현재 Student 클래스임. 실제 사용할때는 이곳에 모든 버퍼를 저장할수 있도록할것!! (구분자 : /)
    Student_info *data = (Student_info*) node->data;

    *buf += (to_string((long double) data -> getMode()) + '/');
    *buf += (data -> getIDcode() + '/');
    *buf += (data -> getName() + '/');
    *buf += (data -> getPassword() + '/');
    *buf += (data -> getBirth() + '/');
    *buf += (to_string((long double) data -> getGrade()) + '/');
    *buf += (to_string((long double) data -> getClass()) + '/');
    for (int i = 0; i < TOTAL_SUBJECT; i++)
        *buf += (to_string((long double) data -> getScore(i)) + '/');
    *buf += (to_string((long double) data ->getScoreSum())  + '/');
    *buf += (to_string((long double) data ->getScoreAvg())  + '/');
    *buf += (to_string((long double) data ->getClassRank())  + '/');
    *buf += (to_string((long double) data ->getEntireRank())  + '\n');

    Avl_FillBuffer (node->left, buf);
    Avl_FillBuffer (node->right, buf);
}

// Delete node
AvlNode* Avl_Delete (AvlNode **root, string key)
{
    if (*root == NULL)
        return *root;
 
    if (key < (*root)->data -> getIDcode())
        (*root)->left = Avl_Delete(&(*root)->left, key);
 
    // If the key to be deleted is greater than the root's key,
    // then it lies in right subtree
    else if(key > (*root)->data -> getIDcode())
        (*root)->right = Avl_Delete(&(*root)->right, key);
 
    // if key is same as root's key, then This is the node
    // to be deleted
    else
    {
        // node with only one child or no child
        if( ((*root)->left == NULL) || ((*root)->right == NULL) )
        {
            AvlNode *temp = (*root)->left ? (*root)->left : (*root)->right;
 
            // No child case
            if(temp == NULL)
            {
                temp = *root;
                *root = NULL;
            }
            else // One child case
             **root = *temp; // Copy the contents of the non-empty child
 
            free(temp);
        }
        else
        {
            // node with two children: Get the inorder successor (smallest
            // in the right subtree)
            AvlNode* temp = minValueNode((*root)->right);
 
            // Copy the inorder successor's data to this node
            (*root)->data = temp->data;
 
            // Delete the inorder successor
            (*root)->right = Avl_Delete(&(*root)->right, temp->data -> getIDcode());
        }
    }
 
    // If the tree had only one node then return
    if (*root == NULL)
      return *root;
 
    (*root) = Make_BalanceTree(root);  

 
    return *root;
}



/*######################################################################
####                                                                ####
####                         L I S T                                ####
####                                                                ####
######################################################################*/

List* createList ()
{
    List* list = new List;
    list->size = 0;
    list->front = NULL;
    
    return list;
}

void destroyList (List* list)
{
    assert (list);

    while(!isEmpty(list))
    {
        delete list->front->data;
        removeFront(list);
    }

    delete list;
    list=NULL;
}

void destroyOnlyList (List* list)
{
    assert (list);

    while(!isEmpty(list))
    {
        removeFront(list);
    }

    delete list;
    list=NULL;
}

bool isEmpty (List* list)
{
    assert (list);
    return list->size == 0;
}

ListNode* getFront (List* list)
{
    assert (list);
    return list->front;
}


void addFront (List* list, void* node)
{
    assert (list);
    ListNode* n = new ListNode;
    n->data = node;
    n->next = NULL;
    
    if (isEmpty(list))
    {
        list->front = n;
    }
    else
    {
        n->next = list->front;
        list->front = n;
    }
    list->size++;
}


// only use in huffman
void removeFront (List* list)
{
    assert (list);
    ListNode* tmp = list->front;
    tmp = tmp->next;
    delete list->front;
    list->front = tmp;
    list->size--;
}


/*
    이    름 : searchList (List* list, string key)
    역    할 : list 종류에 따라 해당 하는 노드를 반환함
                1. Tea_list => Teacher_info
                2. common_list => Search_table         
    파라미터 : list와 검색에 사용 될 Key
    반 환 값 : ListNode* (리스트 노드가 반환)
    기    타 : key가 IDcode로 들어오든, name으로 들어오든 변환 과정을 거치므로 
               key에 대한 구별을 하지 않고 사용할 수 있음.
*/
ListNode* searchList (List* list, string key)
{
    ListNode* cur = NULL;
    
    // search function
    for (cur = list->front; cur != NULL; cur = cur->next)
    {
        if (list == Tea_list)
        {
#if DEBUG_PRINT
        cout << ((Primary_info*)cur->data)->getName() << endl;
#endif
            if (((Primary_info*)cur->data)->getIDcode() == key 
                || ((Primary_info*)cur->data)->getName() == key)
            {
                return cur;
            }
        }

        else if (list == SearchTable_list)
        {
#if DEBUG_PRINT
        cout << ((Search_table*)cur->data)->name << endl;
#endif
            if (((Search_table*)cur->data)->IDcode == key 
                || ((Search_table*)cur->data)->name == key)
            {
                return cur;
            }
        }
    }

    return NULL;
}


void removeKey (List* list, string key)
{
    assert (list);
    ListNode* prev = NULL;
    
    if (list->front->next == NULL)
    {
        removeFront(list);
        return;
    }
    
    for (ListNode* cur = list->front; cur != NULL; cur = cur->next)
    {
        if (list == Tea_list)
        {
            if (((Primary_info*)cur->data)->getIDcode() == key)
            {
                if (cur == list->front)
                {
                    list->front = cur->next;
                }
                else
                {
                    prev->next = cur->next;
                }
                delete cur->data;
                delete cur;
                list->size--;
                break;
            }
            prev = cur;
        }

        else if (list == SearchTable_list)
        {
            if (((Search_table*)cur->data)->IDcode == key)
            {
                if (cur == list->front)
                {
                    list->front = cur->next;
                }
                else
                {
                    prev->next = cur->next;
                }
                delete cur->data;
                delete cur;
                list->size--;
                break;
            }
            prev = cur;
        }
    }
}


/*######################################################################
####                                                                ####
####                       Huffman Code                             ####
####                                                                ####
######################################################################*/

static int ind;	// index (It is used in Huffman)


static TreeNode* createTreeNode ()
{
    TreeNode* node = new TreeNode;
    assert (node);

    node->left = node->right = NULL;
    return node;
}

Tree* createTree ()
{
    Tree* tree = new Tree;
    assert (tree);

    tree->root = createTreeNode();
    tree->size = 0;

    return tree;
}


static void _ProcDestroyTree (TreeNode* root)
{
    if (!root->left && !root->right)
        return;

    _ProcDestroyTree (root->left);
    _ProcDestroyTree (root->right);

    delete root;
}

static void destroyTree (Tree* tree)
{
    assert (tree);

    _ProcDestroyTree (tree->root);
    delete tree;
    tree=NULL;
}


// swap function
static void _swap(void** first, void** second)
{
    void* temp = *first;
    *first = *second;
    *second = temp;

}

static void _SortTable (List* list)
{
    if (!list)
        return;

    // bubble sort
    for (ListNode* i = list->front; i != NULL; i = i->next)
        for (ListNode* j = list->front; j != NULL; j = j->next)
            if (((TreeNode*)i->data)->table.frequency < ((TreeNode*)j->data)->table.frequency)
                _swap(&i->data, &j->data);
}

static void MakeTable (List* list, char* str)
{
    assert(list);

    for (int i=0; i < strlen(str); i++)
    {
        bool exist = false;

        // to find same character in list.
        for(ListNode* n = list->front; n != NULL; n = n->next)
        {
            if (str[i] == ((TreeNode*)n->data)->table.ch)
            {
                ((TreeNode*)n->data)->table.frequency++;
                exist = true;
                break;
            }
        }

        // if do not find same character in list, create node and add list.
        if (!exist)
        {
            TreeNode* node = createTreeNode();
            node->table.ch = str[i];
            node->table.frequency = 1;
            addFront(list, node);
        }
    }

    _SortTable(list);
}

static void MakeHuffmanTree(Tree* tree, List* list)
{
    while(!isEmpty(list))
    {		
        TreeNode *first_node, *second_node;
        TreeNode *root_node = createTreeNode();

        first_node = (TreeNode*)getFront(list)->data;
        tree->size++;
        removeFront(list);

        second_node = (TreeNode*)getFront(list)->data;
        tree->size++;
        removeFront(list);

        root_node->table.ch = 0;	//  flag(NULL)
        root_node->table.frequency = first_node->table.frequency +
            second_node->table.frequency;
        root_node->left = first_node;
        root_node->right = second_node;
        tree->size++;

        if(!isEmpty(list))
        {
            addFront(list, root_node);
            _SortTable(list);
        }

        tree->root = root_node;	
    }
}

static void _ProcEncodingFile (TreeNode* node, char ch, char* code, char* pcode, char** ret)
{
    if(!node)
        return;
    else if (!node->left && !node->right)
    {
        if (node->table.ch == ch)
        {
            *pcode = '\0';
            *ret = new char[strlen(code+1)];
            assert (*ret);
            strncpy(*ret, code, strlen(code)+1);
        }
    }
    else
    {
        *pcode='0';
        _ProcEncodingFile (node->left, ch, code, pcode+1, ret);		// left
        *pcode='1';
        _ProcEncodingFile (node->right, ch, code, pcode+1, ret);	// right
    }
}

static void EncodingFile (Tree* tree, char* str, char* ret)
{
    int index = 0;
    int len = 0;
    char *pcode;

    for(int i=0; i<strlen(str); i++)
    {
        char code[HUFFMAN_CODE_BUF] = {0,};
        ind = 0;
        pcode = NULL;

        _ProcEncodingFile(tree->root, str[i], code, code, &pcode);
        strncat(ret, pcode, strlen(pcode));
        len += strlen(pcode);
    }
    ret[len] = 0;
}

static void DecodingFile(Tree* tree, char* code, char* ret)
{
    int index = 0;
    TreeNode* node = tree->root;

    for(int i=0; i<strlen(code); i++)
    {
        if (code[i] == '0')
            node = node->left;
        else if (code[i] == '1')
            node = node->right;

        if (!node->left && !node->right)
        {
            ret[index++] = node->table.ch;
            node = tree->root;
        }
    }
    ret[index] = 0;
}

static int EncodingBit (char* code, char* ret)
{
    char bit = 0;
    int len  =0, index = 0;

    for (int i = 0; i < strlen(code); i++)
    {
        if (code[i] == '1')
        {
            bit <<= 1;
            bit |= 1;

            len++;
        }
        else 
        {
            bit <<= 1;
            len++;
        }

        if (len == 8)
        {
            ret[index++] = bit;
            len = 0;
            bit = 0;
        }
    }
    
    bit <<= 1;
    bit |= 1;	// End mark
    len++;
    
    if (len != 0)
    {
        for(; len != 8; len++)
        {
            bit <<= 1;
        }
        ret[index++] = bit;
    }

    return index;
}

static void DecodingBit (char* bitstr, int bit_len, char* ret)
{
    char bit=1, code;
    int index=0;

    for (int i=0; i<bit_len; i++)
    {
        for (int j=7; j>=0; j--)
        {
            if (bitstr[i] & (bit<<j))
                ret[index++] = '1';
            else
                ret[index++] = '0';
        }
    }
    for (index=index-1; ret[index]!='1'; index--)
        ret[index] = 0;		// remove surplus bit '0'
    ret[index] = 0;			// remove End mark '1'
}

static void _TreeConvertToParenthesisNotationProc(TreeNode* node, char* ret)
{
    if(!node)
        return;
    if(!node->left && !node->right)
    {
        ret[ind++] = node->table.ch;
        return;
    }  

    ret[ind++] = 1;		// left mark
    _TreeConvertToParenthesisNotationProc(node->left, ret);
    ret[ind++] = 2;     // right mark
    _TreeConvertToParenthesisNotationProc(node->right, ret);
    ret[ind++] = 3;		// end mark
}

static char* TreeConvertToParenthesisNotation(Tree* tree)
{
    assert(tree);
    ind = 0;
    char* str = new char[tree->size * 2];
    _TreeConvertToParenthesisNotationProc(tree->root, str);

    return str;
}


static void _ProcParenthesisNotationConvertToTree(Tree* tree, TreeNode* root, char* treeStr)
{
    if (ind >= strlen(treeStr))
        return;

    if (treeStr[ind] == 1)	//left
    {   
        TreeNode* node = createTreeNode();
        tree->size++;
        node->table.ch = 0;
        root->left = node;
        ind++;
        _ProcParenthesisNotationConvertToTree(tree, root->left, treeStr);
    }   
    else if (treeStr[ind] == 2)	//right
    {   
        TreeNode* node = createTreeNode();
        tree->size++;
        node->table.ch = 0;
        root->right = node;
        ind++;
        _ProcParenthesisNotationConvertToTree(tree, root->right, treeStr);
    }   
    else if (treeStr[ind] == 3)	//end
    {   
        ind++;
        return;
    }   
    else
    {   
        root->table.ch = treeStr[ind];
        ind++;
        return;
    }   
    _ProcParenthesisNotationConvertToTree(tree, root, treeStr);
}

static void ParenthesisNotationConvertToTree(Tree* tree, char* treeStr)
{
    assert(tree);
    TreeNode* root = createTreeNode();
    tree->root = root;
    tree->size++;
    ind = 0;
    _ProcParenthesisNotationConvertToTree(tree, root, treeStr);
}

int Compression (List* list, Tree* tree, char* buf, char** ret, char** ret_treeStr, int* ret_len)
{
    char code[HUFFMAN_BUF_SIZE*HUFFMAN_CODE_BUF] = {0,};
    char tmp[HUFFMAN_BUF_SIZE];

    MakeTable (list, buf);			 					// Make Frequency Table
    
    MakeHuffmanTree (tree, list);	 					// Make Huffman Tree

    EncodingFile (tree, buf, code);						// Convert string to code
    *ret_len = EncodingBit (code, tmp);		 			// Convert code to bit
    
    *ret_treeStr = TreeConvertToParenthesisNotation (tree);  // represent tree to parenthesis notation

    char *bit = new char[*ret_len];
    memcpy (bit, tmp, *ret_len);
    *ret = bit;

    return strlen(code);
}

void Decompression (Tree* tree, char* buf, char** ret, char* treeStr, int bit_len)
{
    char code[HUFFMAN_BUF_SIZE*HUFFMAN_CODE_BUF] = {0,};
    char tmp[HUFFMAN_BUF_SIZE];

    ParenthesisNotationConvertToTree (tree, treeStr);	// Make tree using tree parenthesis notation

    DecodingBit (buf, bit_len, code);					// Convert bit to code
    DecodingFile (tree, code, tmp);	                    // Convert code to string

    char *str = new char[strlen(tmp) + 1];
    memcpy (str, tmp, strlen(tmp));
    str[strlen(tmp)] = '\0';
    *ret = str;
}

void Huffman_FreePointer(List* list, Tree* tree, char* treeStr, char* buf)
{
    if(list)
        destroyList(list);
    if(tree)
        destroyTree(tree);
    if(treeStr)
        delete treeStr;
    if(buf)
        delete buf;
}
