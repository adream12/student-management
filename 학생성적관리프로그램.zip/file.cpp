﻿#include "common.h"
#include "file.h"

/*######################################################################
####                         W R I T E                              ####
######################################################################*/

void writeFile (string buffer)
{
    FILE* file = NULL;
    int len;

    file = fopen("User.dat", "wb+");
    if(!file)
    {
        cout << "Cannot Open File:" << endl;
        return;
    }

#if ERROR_TEST
    FILE* test = NULL;
    test = fopen("test.txt", "wb+");
    fwrite(buffer.c_str(), buffer.length(), 1, test);
#endif

    // print bytes, before compression
    cout << "압축 전 용량 : " << buffer.length() << " bytes" << endl;

#if DEBUG_PRINT
    cout << buffer << endl;
#endif

    cout << "압축 중..." << endl;
    
    // compress
    List* list = createList();
    Tree* tree = createTree();
    char *bit = NULL;
    char *treeStr = NULL;
    int bit_len = 0;
    int code_len = 0;

    code_len = Compression (list, tree, (char*)buffer.c_str(), &bit, &treeStr, &bit_len);

    // print bytes, after compression
    cout << "압축 후 용량 : " << code_len / 8 << " bytes" << endl;

#if DEBUG_PRINT
    cout << bit << endl;
#endif

    PAUSE();

    len = strlen(treeStr);
    if (fwrite(&len, sizeof(int), 1, file) == -1)
    {
        cout << "Failed: Cannot write len." << endl;
        fclose (file);
        return;
    }
    if (fwrite(treeStr, len, 1, file) == -1)
    {
        cout << "Failed: Cannot write treeStr." << endl;
        fclose (file);
        return;
    }
    if (fwrite(&bit_len, sizeof(int), 1, file) == -1)
    {
        cout << "Failed: Cannot write bit_len." << endl;
        fclose (file);
        return;
    }
    if (fwrite(bit, bit_len, 1, file) == -1)
    {
        cout << "Failed: Cannot write str." << endl;
        fclose (file);
        return;
    }

    Huffman_FreePointer (list, tree, treeStr, bit);

    fclose (file);
}



/*######################################################################
####                           R E A D                              ####
######################################################################*/

string readFile ()
{
    FILE* file = NULL;
    char* treeStr = NULL;
    int len = 0;
    int bit_len = 0;
    char bit[HUFFMAN_BUF_SIZE] = {0,};

    file = fopen("User.dat", "rb+");
    if(!file)
    {
        cout << "Cannot Open File:" << endl;
        return "";
    }
    if (fread(&len, sizeof(int), 1, file) == -1)
    {
        cout << "Failed: Cannot Read size len." << endl;
        fclose (file);
        return "";
    }

    treeStr = new char[len + 1];
    if (fread(treeStr, len, 1, file) == -1)
    {
        cout << "Failed: Cannot Read size treeStr." << endl;
        fclose (file);
        return "";
    }
    if (fread(&bit_len, sizeof(int), 1, file) == -1)
    {
        cout << "Failed: Cannot Read str." << endl;
        fclose (file);
        return "";
    }
    if (fread(bit, bit_len, 1, file) == -1)
    {
        cout << "Failed: Cannot Read str." << endl;
        fclose (file);
        return "";
    }

    fclose (file);


#if DEBUG_PRINT
    cout << "테스트 (최초 read) :::: " << strlen(bit) << " bytes" << endl;
#endif

    string buffer;

    if (len == 0)
        return "";

    // decompress
    Tree *tree = createTree();
    char *str = NULL;
    
    Decompression (tree, bit, &str, treeStr, bit_len);
    buffer.assign(str);
    Huffman_FreePointer (NULL, tree, treeStr, str);

#if DEBUG_PRINT
    cout << "테스트 (복원후) :::: " << buffer.length() << " bytes" << endl;
#endif

    return buffer;
}