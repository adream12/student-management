﻿#ifndef _FILE_H_
#define _FILE_H_

#include <string>
using namespace std;

void writeFile (string buffer);
string readFile ();



#endif